import java.util.Scanner;
import java.io.File;
import java.util.ArrayList;

/*
Pre: creates ArrayList of Fractions and counts by using Fraction and FractionCounter class
     and stores FractionCounter objects into the ArrayList and uses it's methods to count
     repeated fractions
     
Post: prints the reduced fraction and counts for each fraction
*/
public class FractionDriver {
   public static void main(String[] args) {
      File file = new File("fractions.txt");
      //Creates a new ArrayList that takes FractionCounter object
      ArrayList<FractionCounter> myCounter = new ArrayList<FractionCounter>();
      
      try (Scanner scanner = new Scanner(file)) {
         while (scanner.hasNextLine()) {
            /*
            Takes each line from other file and turns into String fraction and turns
            that String into Fraction object and reduces it to it's simplest form and 
            makes different object called FractionCounter and takes that new Fraction object
            to use the methods that FractionCounter has
            */
            String fraction = scanner.nextLine();
            Fraction fractionInput = new Fraction(fraction);
            FractionCounter countFraction = new FractionCounter(fractionInput);
            
            /*
            Similar to fractionsv1, the match variable is to default value of "false"
            If the newFraction object that was created in the for loop the same as the
            first fraction object that was made above, then it will up the count in
            compareAndIncrement method in FractionCounter class, and changes the value of match
            into "true"
            */
            boolean match = false;            
            for (FractionCounter newFraction : myCounter) {
               if (newFraction.compareAndIncrement(fractionInput)) {
                  match = true;
                  break;
               }
            }  
            
            /*
            If match stays false after the loop iteration, it means the fraction is unique from the other fraction. 
            It then adds the new object countFraction from above to make it a unique fraction into the FractionCounter ArrayList 
            */ 
            if (match != true) {
               myCounter.add(countFraction);          
            }
         }
         scanner.close();
      }
      
      catch (Exception e) {
         System.out.println("File not found");
      }
      
      //Prints the toString() method from FractionCounter class with override and prints each element from ArrayList
      for (int i = 0; i < myCounter.size(); i++) {
         System.out.println(myCounter.get(i));
      }
   }
}
