public class FractionCounter {
   private Fraction fraction;
   private int counter;
  
   public FractionCounter(Fraction theFraction) {
      fraction = theFraction;
      counter = 1;
   }
   
   //Uses the override of .equals from Fraction class to compare and increment fractions
   public boolean compareAndIncrement(Fraction newFraction) {
      if (fraction.equals(newFraction)) {
         counter++;
         return true;
      }
     
      else {
         return false;
      }
   }
  
   public String toString() {
      return fraction + " has a count of " + counter;
   }
}