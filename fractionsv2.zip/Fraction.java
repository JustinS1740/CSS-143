public class Fraction {
   private int numerator;
   private int denominator;
  
   public Fraction() {
      numerator = 0;
      denominator = 1;
   }
   
   //Takes an input of a String fraction and changes it into it's simplest form by using gcd method
   public Fraction(String fraction) {
      String[] parts = fraction.split("/");
      int num = Integer.parseInt(parts[0]);
      int denom = Integer.parseInt(parts[1]);
      
      int gcd = gcd(num, denom);
     
      numerator = num / gcd;
      denominator = denom / gcd;
   }
   
   public boolean equals(Fraction other) {
      if (other.getNumerator() == numerator  && other.getDenominator() == denominator) {
         return true;
      }
     
      else {
         return false;
      }
   }
  
   public int getNumerator() {
      return numerator;
   }
  
   public int getDenominator() {
      return denominator;
   }
  
   public void setNumerator(int newNum) {
      numerator = newNum;
   }
  
   public void setDenominator(int newDen) {
      denominator = newDen;
   }
   
   //gcd method uses Euclid's algorithm
   public int gcd(int num, int denom) {
      if (denom == 0) {
         return num;
      }
      return gcd(denom, num % denom);
   }
  
   public String toString() {
      return numerator + "/" + denominator;
   }
}
